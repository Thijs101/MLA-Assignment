# MLA final project - code

Reproduces every number and figure in the report (Fashion-MNIST: data analysis,
decision tree, bagging, random forest, gradient boosting reference, and a
one-off check of the CNN design from Part 2).

Packages used: numpy, matplotlib,
scikit-learn (DecisionTreeClassifier, BaggingClassifier, RandomForestClassifier,
GradientBoostingClassifier, KMeans, GridSearchCV), shap (TreeExplainer) and
Keras (TensorFlow). The data are loaded with
`keras.datasets.fashion_mnist.load_data()`, which downloads Fashion-MNIST
the first time it is run.

## Files

- `run_analysis.py` - data analysis (class averages, k-means, pixel statistics),
  decision tree (3-fold CV over max_depth / min_samples_leaf and cost-complexity
  pruning), random forest (number of trees, subset size m) and bagging, noise
  check, SHAP values and pixel selection. Writes Figures 1-5 of the report.
- `gradient_boosting.py` - GradientBoostingClassifier with default settings
  (reference model), including accuracy per round (Figure 6).
- `cnn_keras.py` - optional: trains the proposed CNN and a fully
  connected network once, as a check of the Part 2 design.
- `requirements.txt` - package versions used.

## How to run

1. `pip install -r requirements.txt`
2. From inside `code/`:
   - `python run_analysis.py` (about 50 minutes on a laptop CPU)
   - `python gradient_boosting.py` (about 90 minutes)
   - optional: `python cnn_keras.py` (about 1 hour)

Results are written to `../results/` and figures to `../figures/`.
All random seeds are fixed (`random_state=42`).
